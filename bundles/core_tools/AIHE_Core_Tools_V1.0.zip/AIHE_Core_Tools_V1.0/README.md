# AIHE Core Tools V1.0

A compact convenience package of the consolidated institutional forms and workbooks from the **Digital Resource Companion V1.0** for *Artificial Intelligence and Healthcare Economics: Evidence, Value, Governance, and Sustainability*.

## What is included

### Forms
- `AIHE_Core_Resource_Forms_V1.0.docx` — editable Microsoft Word edition
- `AIHE_Core_Resource_Forms_V1.0.odt` — editable LibreOffice Writer edition
- `AIHE_Core_Resource_Forms_V1.0.pdf` — reading and printing edition

### Workbooks
- `AIHE_Core_Resource_Workbooks_V1.0.xlsx` — Microsoft Excel edition
- `AIHE_Core_Resource_Workbooks_V1.0.ods` — LibreOffice Calc edition
- `WORKBOOK_GUIDE.md` — guidance for selecting, adapting, controlling, and checking workbook use

## Intended use

This pack is for readers and practitioners who want the core editable institutional tools without downloading the complete Reader and Practitioner Edition or Canonical Source repository.

It is a **convenience distribution**, not a separate edition and not the controlling source. For resource-specific updates, reproducible computational materials, worked examples, browser resources, metadata, and machine-readable source files, use the current Digital Resource Companion repository and Canonical Source release.

The resources are intended for education, structured analysis, decision support, and local adaptation. Institutional use should reflect the relevant jurisdiction, organization, population, workflow, technical environment, evidence base, governance requirements, and accountable decision process.

## Version

V1.0
